function sayHello() {
  console.log("你好，我是工具类");
}

sayHello()